import streamlit as st
import joblib
import pandas as pd

model = joblib.load("models/trained_model.pkl")  # ✅ Correct


st.title("Car Price Predictor")

# Input form
year = st.number_input("Year", min_value=2000, max_value=2025)
mileage = st.number_input("Mileage", min_value=0)
engine_size = st.number_input("Engine Size (L)", step=0.1)
fuel_type = st.selectbox("Fuel Type", ["Petrol", "Diesel", "Electric"])
make = st.selectbox("Make", ["BMW", "Toyota", "Honda"])
model_name = st.selectbox("Model", ["Model A", "Model B", "Model C"])  # Customize as per data

# One-hot encode as done in training
input_dict = {
    "Year": year,
    "Mileage": mileage,
    "Engine Size": engine_size,
    # Add encoded columns similarly...
}

df = pd.DataFrame([input_dict])

if st.button("Predict"):
    pred = model.predict(df)[0]
    st.success(f"Estimated Price: ₹{pred:,.2f}")