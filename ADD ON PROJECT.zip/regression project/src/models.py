from sklearn.linear_model import LinearRegression
import joblib
import os

def train_model(X, y):
    model = LinearRegression()
    model.fit(X, y)

    # Save model
    model_path = os.path.join(os.path.dirname(__file__), '..', 'models', 'trained_model.pkl')
    joblib.dump(model, model_path)

    return model
