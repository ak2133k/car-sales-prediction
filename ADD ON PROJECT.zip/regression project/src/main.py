from src.data import load_data
from src.models import train_model
import pandas as pd

# Load data
df = load_data()

# Use only 'Year' as input
X = df[['Year']]
y = df['Price']

# Train and save model
model = train_model(X, y)

# Predict future value
future_year = 2025
future_input = pd.DataFrame([[future_year]], columns=["Year"])  # match feature name
predicted_price = model.predict(future_input)

print(f"Predicted price for a {future_year} car: ${predicted_price[0]:,.2f}")
