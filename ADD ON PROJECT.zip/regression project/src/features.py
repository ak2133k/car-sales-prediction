def process_features(df):
    # Drop rows with null values (simple preprocessing)
    df = df.dropna()

    # Encode categorical values (one-hot or label encode)
    df = pd.get_dummies(df, columns=["Make", "Model", "Fuel Type"], drop_first=True)

    X = df.drop("Price", axis=1)
    y = df["Price"]
    return X, y