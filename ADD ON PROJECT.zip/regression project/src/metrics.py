from sklearn.metrics import mean_squared_error

def evaluate_model(model, X, y):
    preds = model.predict(X)
    mse = mean_squared_error(y, preds)
    with open("outputs/results.txt", "w") as f:
        f.write(f"MSE: {mse}")